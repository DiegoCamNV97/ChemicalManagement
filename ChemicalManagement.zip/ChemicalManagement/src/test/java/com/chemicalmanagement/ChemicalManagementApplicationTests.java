package com.chemicalmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChemicalManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
